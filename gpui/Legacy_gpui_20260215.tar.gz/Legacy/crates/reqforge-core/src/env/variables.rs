// Variables module - to be implemented
