//! UI implementation for ReqForge using gpui-component.

mod root;
mod sidebar;

// UI modules - gpui-component implementations
mod env_editor_modal;
mod env_selector;
mod key_value_editor;
mod request_editor;
mod response_viewer;
mod tab_bar;

pub use root::RootView;
pub use sidebar::{SidebarPanel, init as init_sidebar};
pub use env_selector::{EnvSelector, init as init_env_selector};
pub use env_editor_modal::{EnvEditorModal, init as init_env_editor_modal};
pub use key_value_editor::{KeyValueEditor, KeyValueRow, EditorType};
pub use request_editor::RequestEditor;
pub use response_viewer::ResponseViewer;
pub use tab_bar::{RequestTabBar, init as init_tab_bar};